package com.microsoft.band.sdk.gsr;

/**
 * Created by wenbing on 9/11/17.
 */

public class GSRData {
    long ts;
    int gsrValue;
}
