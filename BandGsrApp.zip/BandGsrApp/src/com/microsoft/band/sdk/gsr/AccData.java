package com.microsoft.band.sdk.gsr;

/**
 * Created by wenbing on 9/11/17.
 */

public class AccData {
    float x;
    float y;
    float z;
    long ts;
}
