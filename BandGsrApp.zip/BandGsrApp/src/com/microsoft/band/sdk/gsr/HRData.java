package com.microsoft.band.sdk.gsr;

/**
 * Created by wenbing on 9/12/17.
 */

public class HRData {
    long ts;
    int hr;
    String quality;
}
