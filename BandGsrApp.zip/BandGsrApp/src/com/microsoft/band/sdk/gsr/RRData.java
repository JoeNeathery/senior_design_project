package com.microsoft.band.sdk.gsr;

/**
 * Created by wenbing on 9/13/17.
 */

public class RRData {
    long ts;
    double rr;
}
