package com.example.g29.msbandapp;
/**
 * Created by Joe on 11/5/18.
 * Gyroscope Data
 */

public class GyrData {
    long ts;
    double avx;
    double avy;
    double avz;
}
