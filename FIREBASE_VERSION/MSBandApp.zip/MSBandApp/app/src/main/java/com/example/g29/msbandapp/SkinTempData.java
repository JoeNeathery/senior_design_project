package com.example.g29.msbandapp;

/**
 * Created by Joe on 11/5/18.
 * Skin Temperature Data
 */

public class SkinTempData {
    long ts;
    double temperature_cel;
    double temperature_fah;
}
