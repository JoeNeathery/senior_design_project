package com.example.g29.msbandapp;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.NumberPicker;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.microsoft.band.BandClient;
import com.microsoft.band.BandClientManager;
import com.microsoft.band.BandException;
import com.microsoft.band.BandInfo;
import com.microsoft.band.ConnectionState;
import com.microsoft.band.sensors.HeartRateConsentListener;
import com.microsoft.band.sensors.BandHeartRateEvent;
import com.microsoft.band.sensors.BandHeartRateEvent;
import com.microsoft.band.UserConsent;
import android.os.AsyncTask;

import java.lang.ref.WeakReference;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;


public class HomeActivity extends Activity {
    private TextView WelcomeMsg, ErrorTxt, DataTxt;
    private Button LogoutBtn, StartBtn, StopBtn, UpdateBtn,  ReportBtn, SetTimerBtn; //MobileDataSaveBtn,
    private FirebaseAuth firebaseAuth;
    private BandClient client = null;
    //private boolean useMobileData = false;
    private Timer execute_timer;
    private NumberPicker SecPicker, HourPicker, MinPicker;
    private Integer secondValue = 0, minValue = 0, hourValue = 0;

    private DataCollectionService mBoundService;
    boolean mIsBound;


    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            // This is called when the connection with the service has been
            // established, giving us the service object we can use to
            // interact with the service.  Because we have bound to a explicit
            // service that we know is running in our own process, we can
            // cast its IBinder to a concrete class and directly access it.
            mBoundService = ((DataCollectionService.LocalBinder) service).getService();
            startDataCollection();
            System.out.println("onServiceConnected is called");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
            // Because it is running in our same process, we should never
            // see this happen.
            mBoundService = null;
        }
    };

    void doBindService(){
        // Establish a connection with the service.  We use an explicit
        // class name because we want a specific service implementation that
        // we know will be running in our own process (and thus won't be
        // supporting component replacement by other applications).
        bindService(new Intent(this, DataCollectionService.class),
                mConnection, Context.BIND_AUTO_CREATE);
        mIsBound = true;
        System.out.println("doBindService");
    }

    void doUnbindService(){
        if(mIsBound){
            //Detach our existing connection
            unbindService(mConnection);
            mIsBound = false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        setupUIViews();
        welcomeUser();
        final WeakReference<Activity> reference = new WeakReference<Activity>(this);


        LogoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //stop data collection if necessary
                if(!StartBtn.isEnabled()){
                    stopDataCollection();
                }
                //unbind Service
                doUnbindService();
                //sign user out and return to login screen
                firebaseAuth.signOut();
                Intent logIntent = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(logIntent);
            }
        });


        StartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //clear Data UI and Error UI on Start
                appendToUI(1, "");
                appendToUI(3, "");
                new HeartRateConsentTask().execute(reference);
            }
        });

        StopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopDataCollection();

            }
        });

        UpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateData();
            }
        });

/*        MobileDataSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check if mobile data saving is on or off
                if(useMobileData){
                    //mobile data saving is ON, turn off
                    useMobileData = false;
                    MobileDataSaveBtn.setText("Turn ON Save Over Mobile Data");
                }else{
                    //mobile data saving is OFF, turn on
                    useMobileData = true;
                    //clear error
                    appendToUI(0, "");
                    MobileDataSaveBtn.setText("Turn OFF Save Over Mobile Data");
                }
            }
        });*/

        ReportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //generateReport();
            }
        });

        SecPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                secondValue = newVal;

                if(secondValue == 0 && MinPicker.getValue() == 0 && HourPicker.getValue() == 0)
                {
                    SetTimerBtn.setEnabled(false);
                }else if(HourPicker.getValue() == 24 && (secondValue > 0 || MinPicker.getValue() > 0)){
                    HourPicker.setValue(0);
                }else{
                    SetTimerBtn.setEnabled(true);
                }
            }
        });

        MinPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                minValue = newVal;

                if(minValue == 0 && SecPicker.getValue() == 0 && HourPicker.getValue() == 0)
                {
                    SetTimerBtn.setEnabled(false);
                }else if(HourPicker.getValue() == 24 && (minValue > 0 || SecPicker.getValue() > 0)){
                    HourPicker.setValue(0);
                }else{
                    SetTimerBtn.setEnabled(true);
                }
            }
        });

        HourPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
                hourValue = newVal;

                if(hourValue == 0 && MinPicker.getValue() == 0 && SecPicker.getValue() == 0)
                {
                    SetTimerBtn.setEnabled(false);
                }else if(hourValue == 24){
                    MinPicker.setValue(0);
                    SecPicker.setValue(0);
                }else{
                    SetTimerBtn.setEnabled(true);
                }
            }
        });

        SetTimerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int secMilli = secondValue * 1000;
                int minMilli = minValue * 60000;
                int hourMilli = hourValue * 3600000;
                long timeMilli = secMilli + minMilli + hourMilli;

                timer_toggle(0, timeMilli);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //if (client != null) {
         //   stopDataCollection();
        //}
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        /*if (client != null) {
            try {
                stopDataCollection();
                client.disconnect().await();
            } catch (InterruptedException e) {
                // Do nothing as this is happening during destroy
            } catch (BandException e) {
                // Do nothing as this is happening during destroy
            }
        }

        */

    }

    private void setupUIViews() {
        WelcomeMsg = findViewById(R.id.welcomeMsg);
        LogoutBtn = findViewById(R.id.signOutBtn);
        firebaseAuth = FirebaseAuth.getInstance();
        ErrorTxt = findViewById(R.id.errorTxt);
        DataTxt = findViewById(R.id.dataTxt);
        StartBtn = findViewById(R.id.startBtn);
        StopBtn = findViewById(R.id.stopBtn);
        UpdateBtn = findViewById(R.id.updateBtn);
        //MobileDataSaveBtn = findViewById(R.id.mblDataBtn);
        ReportBtn = findViewById(R.id.reportBtn);
        SecPicker = findViewById(R.id.secPicker);
        MinPicker = findViewById(R.id.minPicker);
        HourPicker = findViewById(R.id.hourPicker);
        SetTimerBtn = findViewById(R.id.setTimerBtn);

        SetTimerBtn.setEnabled(false);

        SecPicker.setMaxValue(59);
        SecPicker.setMinValue(0);

        MinPicker.setMaxValue(59);
        MinPicker.setMinValue(0);

        HourPicker.setMaxValue(24);
        HourPicker.setMinValue(0);
    }

    private void timer_toggle(int status, long time){
        //timer is not running, start timer
        if(status == 0){
            //start new timer task and timer
            TimerTask task = new TimerTask() {
                @Override
                public void run(){
                    updateData();
                }
            };

            if(execute_timer != null){
                execute_timer.cancel();
                execute_timer.purge();
            }
            execute_timer = new Timer();
            execute_timer.scheduleAtFixedRate(task, 0, time); //every five min 300,000ms
        }else{
            //stop timer and stop timer task
            execute_timer.cancel();
            execute_timer.purge();
        }
    }

    private void welcomeUser() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        appendToUI(2, "Welcome " + user.getDisplayName() + "!");

    }

    private void appendToUI(final int ui, final String message){
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                switch(ui){
                    case 1:
                        //DataTxt
                        DataTxt.setText(message);
                        break;
                    case 2:
                        //WelcomeTxt
                        WelcomeMsg.setText(message);
                        break;
                    default:
                        //ErrorTxt
                        ErrorTxt.setText(message);
                        break;
                }
            }
        });
    }

    private void updateData(){
        if(mIsBound && mBoundService != null) {
            appendToUI(0, "");
            ContData contData = mBoundService.getContData();

            //band is being worn, so collect rest of data
            // if(contData.contactState == BandContactState.WORN){
            AccData accData = mBoundService.getAccData();
            AltData altData = mBoundService.getAltData();
            AmbData ambData = mBoundService.getAmbData();
            BarData barData = mBoundService.getBarData();
            CalData calData = mBoundService.getCalData();
            DistData distData = mBoundService.getDistData();
            GSRData gsrData = mBoundService.getGsrdata();
            GyrData gyrData = mBoundService.getGyrData();
            HRData hrData = mBoundService.getHrdata();
            PedData pedData = mBoundService.getPedData();
            RRData rrData = mBoundService.getRRData();
            SkinTempData skinTempData = mBoundService.getSkinTempData();
            UVData uvData = mBoundService.getUVData();

            String text = "Skin Resistance = " + gsrData.gsrValue + " kOhms\nHeart Rate = " + hrData.hr + " beats per min.\nRR = " + rrData.rr;
            appendToUI(1, text);

            //check for internet connection
            //if(checkInternetConnection()){
            //package into one Object for saving
            UserSaveData usrData = new UserSaveData();
            usrData.accData = accData;
            usrData.altData = altData;
            usrData.ambData = ambData;
            usrData.barData = barData;
            usrData.calData = calData;
            usrData.contData = contData;
            usrData.distData = distData;
            usrData.gsrData = gsrData;
            usrData.gyrData = gyrData;
            usrData.hrData = hrData;
            usrData.pedData = pedData;
            usrData.rrData = rrData;
            usrData.skinTempData = skinTempData;
            usrData.uvData = uvData;
            usrData.ts_ms = System.currentTimeMillis();
            Date currentDate = new Date(usrData.ts_ms);

            saveData(usrData, currentDate);
/*            //check if user allows saving over mobile data
            if (!useMobileData) {
                //check for wifi connection
                if (checkWifiConnection()) {
                    //wifi connected, save data
                    saveData(usrData, currentDate);
                } else {
                    //no wifi connection, throw error
                    appendToUI(0, "No WiFi Connection. Data will not be saved.");
                }
            } else {
                //user allows saving over mobile data or wifi.
                saveData(usrData, currentDate);
            }*/

        }else if(mBoundService == null){
            appendToUI(0, "Connection to Service is being Established. Please wait.");
        }else{
            appendToUI(0, "No Internet Connection. Data will not be saved.");
        }
            //}else{
            //throw error and stop data collection
            //  appendToUI(1, "Please ensure Band is being worn.");
            // stopDataCollection();
            //}
        }
    //}


/*
    //report is only daily for now
    private void generateReport(){
        FirebaseDatabase db = FirebaseDatabase.getInstance().getReference().getDatabase();
        DatabaseReference ref = db.getReference();

        final String uid = firebaseAuth.getCurrentUser().getUid();
        Date currentDate = new Date();
        DateFormat year = new SimpleDateFormat("yyyy");
        DateFormat month = new SimpleDateFormat("MMM");
        DateFormat day = new SimpleDateFormat("dd");
        final String currentYear = year.format(currentDate);
        final String currentMonth = month.format(currentDate);
        final String currentDay = day.format(currentDate);

        //retrieve database entry
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                dataSnapshot.
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    */
    //save data method, save ALL possible data (subject to change)
    private void saveData(UserSaveData usrData, Date currentDate){
        //connect to database
        FirebaseDatabase db = FirebaseDatabase.getInstance().getReference().getDatabase();
        DatabaseReference ref = db.getReference();

        //get userId
        String uid = firebaseAuth.getCurrentUser().getUid();

        //format date for database architecture
        DateFormat year = new SimpleDateFormat("yyyy");
        DateFormat month = new SimpleDateFormat("MMM");
        DateFormat day = new SimpleDateFormat("dd");
        DateFormat hour = new SimpleDateFormat("HH");
        DateFormat minAndSec = new SimpleDateFormat("mm:ss");
        //architecture of DB is: UserID - Year - Month - Day - Hour (24-based) : Min - User Health Data
        ref.child(uid).child(year.format(currentDate)).child(month.format(currentDate)).child(day.format(currentDate)).child(hour.format(currentDate)).child(minAndSec.format(currentDate)).setValue(usrData);
    }



    private boolean checkWifiConnection(){
        //check Wifi connection
        WifiManager wifiMgr = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        //Wifi adapter is ON
        if(wifiMgr.isWifiEnabled()){
            WifiInfo wifiInfo = wifiMgr.getConnectionInfo();
            //not connected to an access point
            if(wifiInfo.getNetworkId() == -1){
                return false;
            }
        }else{
            return false;
        }

        //connected to wifi
        return true;
    }

    private boolean checkInternetConnection(){
        //check for internet connection
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();

        if(networkInfo != null && networkInfo.isConnected()){
            //connected to internet
            return true;
        }else{
            //no internet connection
            return false;
        }

    }

    private void startDataCollection(){
        //disable start btn, enable stop and update btn
        StopBtn.setEnabled(true);
        UpdateBtn.setEnabled(true);
        StartBtn.setEnabled(false);

        doBindService();
        updateData();
        HourPicker.setValue(0);
        MinPicker.setValue(1);
        SecPicker.setValue(0);
        timer_toggle(0, 60000);
    }

    private void stopDataCollection(){
        appendToUI(0, "Data Collection has been STOPPED.");

        //stop timer used to update data every five min
        timer_toggle(1, 0);

        //disable stop and update btn, enable start btn
        StopBtn.setEnabled(false);
        StartBtn.setEnabled(true);
        UpdateBtn.setEnabled(false);

        doUnbindService();
    }

    private boolean getConnectedBandClient() throws InterruptedException, BandException {
        if (client == null) {
            BandInfo[] devices = BandClientManager.getInstance().getPairedBands();
            if (devices.length == 0) {
                appendToUI(3, "Band isn't paired with your phone.\n");
                return false;
            }
            client = BandClientManager.getInstance().create(getBaseContext(), devices[0]);
        } else if (ConnectionState.CONNECTED == client.getConnectionState()) {
            return true;
        }

        System.out.println("Band is connecting...\n");
        return ConnectionState.CONNECTED == client.connect().await();
    }

    private class HeartRateConsentTask extends AsyncTask<WeakReference<Activity>, Void, Void> {
        protected Void doInBackground(WeakReference<Activity>... params) {
            try {
                if (getConnectedBandClient()) {
                    if (params[0].get() != null) {
                        client.getSensorManager().requestHeartRateConsent(params[0].get(), new HeartRateConsentListener() {
                            @Override
                            public void userAccepted(boolean consentGiven) {
                                if(consentGiven){
                                    startDataCollection();
                                }
                            }
                        });
                    }
                } else {
                    //band still not connected, even after reconnection attempt. Throw error
                    appendToUI(3, "Band not connected.\n " +
                            "Please ensure Band is connected to your device.");
                }
            } catch (Exception e) {
                appendToUI(3, e.getMessage());
            }

            return null;
        }
    }
}




