package com.example.g29.msbandapp;

/**
 * Created by wenbing on 9/11/17.
 * GSR Data
 */

public class GSRData {
    long ts;
    int gsrValue;
}
