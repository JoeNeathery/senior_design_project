package com.example.g29.msbandapp;

import com.microsoft.band.sensors.UVIndexLevel;

/**
 * Created by Joe on 11/5/18.
 * UV Data
 */

public class UVData {
    long ts;
    UVIndexLevel indexLevel;
    String indexLevelStr;

}
