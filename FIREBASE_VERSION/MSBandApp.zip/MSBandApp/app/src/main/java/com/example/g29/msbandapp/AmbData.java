package com.example.g29.msbandapp;

/**
 * Created by Joe on 11/5/18.
 * Ambient Light Data
 */
public class AmbData {
    long ts;
    int brightness;
}
