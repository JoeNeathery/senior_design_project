package com.example.g29.msbandapp;

/**
 * Created by Joe on 11/5/18.
 * Pedometer Data
 */

public class PedData {
    long ts;
    long totalSteps;
}
