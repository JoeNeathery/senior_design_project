package com.example.g29.msbandapp;

import com.microsoft.band.sensors.MotionType;

/**
 * Created by Joe on 11/5/18.
 * Distance Data
 */

public class DistData {
    long ts;
    MotionType t;
    String motionTypeStr;
    float pace;
    float speed;
    long totalDistance;
}
