package com.example.g29.msbandapp;

/**
 * Created by wenbing on 9/11/17.
 * Accelerometer Data
 */

public class AccData {
    float x;
    float y;
    float z;
    long ts;

}



