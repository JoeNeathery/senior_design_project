package com.example.g29.msbandapp;

import com.microsoft.band.sensors.BandContactState;

/**
 * Created by Joe on 10/29/18.
 * Band Contact Data
 */

public class ContData {
    long ts;
    BandContactState contactState;
    String contactStateStr;
}
