package com.example.g29.msbandapp;

/**
 * Created by wenbing on 9/12/17.
 * Heart Data Data
 */

public class HRData {
    long ts;
    int hr;
    String quality;
}
