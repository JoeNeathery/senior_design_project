package com.example.g29.msbandapp;

/**
 * Created by Joe on 11/5/18.
 * Calories Data
 */

public class CalData {
    long ts;
    long calories;
}
