package com.example.g29.msbandapp;

/**
 * Created by wenbing on 9/13/17.
 * RR Data
 */

public class RRData {
    long ts;
    double rr;
}